﻿using System;
using RatingDemo.ViewModels;

namespace RatingDemo.Models
{
    public class RatingModel : BaseNotify
    {
        private int _Id;
        public int Id
        {
            get { return _Id; }
            set { SetProperty(ref _Id, value); }
        }

        private string _Image = "star";
        public string Image
        {
            get { return _Image; }
            set { SetProperty(ref _Image, value); }
        }

        private bool _IsSelected;
        public bool IsSelected
        {
            get { return _IsSelected; }
            set {
                SetProperty(ref _IsSelected, value);
                if (value)
                {
                    Image = "yellow_star";
                }
                else
                {
                    Image = "star";
                }
            }
        }




    }
}
