﻿using System;
namespace RatingDemo.Helpers
{
    public static class Constants
    {
        public static string FromCamera = "From Camera";
        public static string FromGallery = "From Gallery";
        public static string CancelButton = "Cancel";
        public static string NoCamera = "No Camera";
        public static string NoCameraAvaialble = "No Camera available";
        public static string OkText = "OK";
        public static string AlertText = "Alert";
        public static string PhotosNotSupported = "Photos not supported";
        public static string PermissionNotGrantedToPhotos = "Permission not granted for Photos";
        public static string Error = "Error";

        
    }
}
