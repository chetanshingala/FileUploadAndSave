﻿using System;
using System.IO;
using Plugin.Media;
using Plugin.Media.Abstractions;
using RatingDemo.Helpers;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace RatingDemo.Services
{
    public static class CommonUtilityService
    {
        public static async void ImagePicker(Action<MediaFile> result, string action = "")
        {
            try
            {
                MediaFile mediaFile = new MediaFile(null, null);

                if (string.IsNullOrEmpty(action))
                {
                    var isCamera = await App.Current.MainPage.DisplayAlert("Pick From", "Select one option pick image.", Constants.FromCamera, Constants.FromGallery);
                    if (isCamera)
                    {
                        action = Constants.FromCamera;
                    }
                    else
                    {
                        action = Constants.FromGallery;
                    }

                    //var actionPopup = new CustomActionPopup();
                    //await PopupNavigation.Instance.PushAsync(actionPopup, true);
                    //var vm = actionPopup.BindingContext as CustomActionPopupViewModel;
                    //action = await vm.PageClosedTask;

                    if (action == Constants.CancelButton) return;
                }

                if (action == Constants.FromCamera)//"From Camera"
                {
                    var cameraPermissionStatus = await Permissions.CheckStatusAsync<Permissions.Camera>();
                    if (cameraPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        cameraPermissionStatus = await Permissions.RequestAsync<Permissions.Camera>();
                    }

                    var storageWritePermissionStatus = await Permissions.CheckStatusAsync<Permissions.StorageWrite>();
                    if (storageWritePermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        storageWritePermissionStatus = await Permissions.RequestAsync<Permissions.StorageWrite>();
                    }

                    var storageReadPermissionStatus = await Permissions.CheckStatusAsync<Permissions.StorageRead>();
                    if (storageReadPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        storageReadPermissionStatus = await Permissions.RequestAsync<Permissions.StorageRead>();
                    }

                    if (cameraPermissionStatus == Xamarin.Essentials.PermissionStatus.Granted &&
                        storageReadPermissionStatus == Xamarin.Essentials.PermissionStatus.Granted &&
                        storageWritePermissionStatus == Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            if (!CrossMedia.Current.IsCameraAvailable)
                            {
                                await App.Current.MainPage.DisplayAlert(Constants.NoCamera, Constants.NoCameraAvaialble, Constants.OkText);
                                return;
                            }

                            mediaFile = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                            {
                                Directory = "Sample",
                                Name = "test.jpg"
                            });

                            if (mediaFile != null && !string.IsNullOrEmpty(mediaFile.Path))
                            {
                                result.Invoke(mediaFile);
                            }
                            else
                            {
                                result.Invoke(null);
                            }
                        });
                    }
                    else
                    {
                        if (cameraPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Camera permission is required", Constants.OkText);
                        }
                        else if (storageWritePermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Storage Read/Write permission is required", Constants.OkText);
                        }
                        else if (storageReadPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Storage Read/Write permission is required", Constants.OkText);
                        }
                        else
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Camera permission is required", Constants.OkText);
                        }
                        result.Invoke(null);
                    }
                }
                else if (action == Constants.FromGallery)//"From Gallery"
                {
                    var photoPermissionStatus = await Permissions.CheckStatusAsync<Permissions.Photos>();
                    if (photoPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        photoPermissionStatus = await Permissions.RequestAsync<Permissions.Photos>();
                    }

                    var storageWritePermissionStatus = await Permissions.CheckStatusAsync<Permissions.StorageWrite>();
                    if (storageWritePermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        storageWritePermissionStatus = await Permissions.RequestAsync<Permissions.StorageWrite>();
                    }

                    var storageReadPermissionStatus = await Permissions.CheckStatusAsync<Permissions.StorageRead>();
                    if (storageReadPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        storageReadPermissionStatus = await Permissions.RequestAsync<Permissions.StorageRead>();
                    }

                    if (photoPermissionStatus == Xamarin.Essentials.PermissionStatus.Granted &&
                        storageReadPermissionStatus == Xamarin.Essentials.PermissionStatus.Granted &&
                        storageWritePermissionStatus == Xamarin.Essentials.PermissionStatus.Granted)
                    {
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            if (!CrossMedia.Current.IsPickPhotoSupported)
                            {
                                await App.Current.MainPage.DisplayAlert(Constants.PhotosNotSupported, Constants.PermissionNotGrantedToPhotos, "OK");
                                return;
                            }

                            mediaFile = await CrossMedia.Current.PickPhotoAsync();

                            if (mediaFile != null && !string.IsNullOrEmpty(mediaFile.Path))
                            {
                                result.Invoke(mediaFile);
                            }
                            else
                            {
                                result.Invoke(null);
                            }
                        });
                    }
                    else
                    {
                        if (photoPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Photo permission is required", Constants.OkText);
                        }
                        else if (storageWritePermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Storage Read/Write permission is required", Constants.OkText);
                        }
                        else if (storageReadPermissionStatus != Xamarin.Essentials.PermissionStatus.Granted)
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Storage Read/Write permission is required", Constants.OkText);
                        }
                        else
                        {
                            await App.Current.MainPage.DisplayAlert(Constants.AlertText, "Photo permission is required", Constants.OkText);
                        }
                        result.Invoke(null);
                    }
                }
            }
            catch (Exception ex)
            {
                await App.Current.MainPage.DisplayAlert(Constants.Error, ex.Message, Constants.OkText);
                result.Invoke(null);
            }
        }

        public static string ConvertMediaFileToBase64String(MediaFile file)
        {
            var memoryStream = new MemoryStream();
            file.GetStream().CopyTo(memoryStream);

            byte[] imageArray = memoryStream.ToArray();

            return Convert.ToBase64String(imageArray);
        }
    }
}
