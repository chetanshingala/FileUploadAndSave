﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using Plugin.Media.Abstractions;
using RatingDemo.Helpers;
using RatingDemo.Services;
using Xamarin.Forms;

namespace RatingDemo.ViewModels
{
    public class FileUploadPageViewModel : BaseViewModel
    {
        public FileUploadPageViewModel()
        {
        }

        private MediaFile _mediaFile;
        private string URL { get; set; }

        private ImageSource _ProfileImage;
        public ImageSource ProfileImage
        {
            get { return _ProfileImage; }
            set
            {
                SetProperty(ref _ProfileImage, value);
            }
        }

        public Command UploadImageCommand { get { return new Command(OnUploadImageCommandExecuted); } }
        private void OnUploadImageCommandExecuted()
        {
            CommonUtilityService.ImagePicker(async (MediaFile file) =>
            {
                if (file == null)
                {
                    await App.Current.MainPage.DisplayAlert(Constants.Error, "Failed retrive Image. Try again!", Constants.OkText);
                    return;
                }
                else
                {
                    try
                    {
                        var base64 = CommonUtilityService.ConvertMediaFileToBase64String(file);
                        ProfileImage = ImageSource.FromStream(() => file.GetStream());
                        await UploadFile(file, "Chetan", "chetanshingala99@gmail.com", "suggetion", "5", "some comments about the app.." );
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }
                }
            });//, Constants.FromGallery);

        }



        public async Task UploadFile(MediaFile file, string name, string email, string feedbackType, string rating, string comments)
        {
            try
            {
                var image = file.GetStream();
                var client = new HttpClient();

                var baseURL = "http://localhost:5000";
                var url = baseURL + "/Uploads/api/Files/Upload";

                MultipartFormDataContent multiContent = new MultipartFormDataContent();

                // Image 1
                HttpContent fileStreamContent1 = new StreamContent(image);
                fileStreamContent1.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("form-data")
                {
                    Name = "File",
                    FileName = Guid.NewGuid() + ".png" // e.g. image1.jpg
                };
                fileStreamContent1.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                multiContent.Add(fileStreamContent1);

                // Additional data for image 1
                multiContent.Add(new StringContent(name), "Name");
                multiContent.Add(new StringContent(email), "Email");
                multiContent.Add(new StringContent(feedbackType), "FeedbackType");
                multiContent.Add(new StringContent(rating), "Rating");
                multiContent.Add(new StringContent(comments), "Comments");

                // Send (url = url of api)
                var response = await client.PostAsync(url, multiContent);

                Debug.WriteLine("-----Response Code: " + response.StatusCode);

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

        }
    }
}
