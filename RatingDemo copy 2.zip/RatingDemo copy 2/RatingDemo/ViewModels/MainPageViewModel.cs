﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using RatingDemo.Models;
using Xamarin.Forms;

namespace RatingDemo.ViewModels
{
    public class MainPageViewModel : BaseViewModel
    {
        public MainPageViewModel()
        {
            RatingList = new ObservableCollection<RatingModel>();
            RatingList.Add(new RatingModel() { Id = 1, IsSelected = false });
            RatingList.Add(new RatingModel() { Id = 2, IsSelected = false });
            RatingList.Add(new RatingModel() { Id = 3, IsSelected = false });
            RatingList.Add(new RatingModel() { Id = 4, IsSelected = false });
            RatingList.Add(new RatingModel() { Id = 5, IsSelected = false });
        }

        private ObservableCollection<RatingModel> _RatingList = new ObservableCollection<RatingModel>();
        public ObservableCollection<RatingModel> RatingList
        {
            get { return _RatingList; }
            set { SetProperty(ref _RatingList, value); }
        }

        private RatingModel _SelectedRating;
        public RatingModel SelectedRating
        {
            get { return _SelectedRating; }
            set { SetProperty(ref _SelectedRating, value); }
        }



        public Command StarClickCommand { get { return new Command<RatingModel>(OnStarClickCommandExecuted); } }
        private void OnStarClickCommandExecuted(RatingModel item)
        {
            try
            {
                SelectedRating = item;
                foreach (var ratingModel in RatingList)
                {
                    if (ratingModel.Id <= item.Id)
                    {
                        ratingModel.IsSelected = true;
                    }
                    else {
                        ratingModel.IsSelected = false;
                    }
                }
                
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

    }
}
