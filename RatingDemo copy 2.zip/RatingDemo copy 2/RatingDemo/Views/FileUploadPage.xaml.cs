﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace RatingDemo.Views
{
    public partial class FileUploadPage : ContentPage
    {
        public FileUploadPage()
        {
            InitializeComponent();
        }
    }
}
