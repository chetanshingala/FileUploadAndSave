﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace FileUploadServerSideDemo.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class UploadsController : ControllerBase
    {
        private readonly IWebHostEnvironment _env;

        public UploadsController(IWebHostEnvironment env)
        {
            _env = env;
        }

        [HttpPost]
        [Route("api/Files/Upload")]
        public async Task<JsonResult> Post(IFormFile formFile)
        {
            try
            {

                string contentRootPath = _env.ContentRootPath;

                if (Request.Form.Files.Count > 0)
                {
                    // Get files
                    foreach (var file in Request.Form.Files)
                    {
                        var postedFile = file;
                        var fileName = postedFile.FileName.Split('\\').LastOrDefault().Split('/').LastOrDefault();

                        var filePath = Path.Combine(contentRootPath, "Uploads/" + fileName);

                        Console.WriteLine("File" + ": " + filePath);

                        using (Stream fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await file.CopyToAsync(fileStream);
                        }
                    }

                    //Get parameter related to file.
                    foreach (var file in Request.Form)
                    {
                        Console.WriteLine(file.Key + ": " + file.Value);
                    }
                }

                var result = new { StatusCode = 200, Value = "Success", ContentType = "application/json" };
                return new JsonResult(result);
                
            }
            catch (Exception exception)
            {
                return new JsonResult( new { StatusCode = 400, Value = "Error" + exception.Message, ContentType = "application/json" });
                //return exception.Message;
            }

            //return "no files";
        }
    }
}